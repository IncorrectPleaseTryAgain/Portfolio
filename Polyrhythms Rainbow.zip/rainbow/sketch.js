/*
* Author: 
Michael Steenkamp

* Date: 
11-07-2023

* Name: 
Polyrhythms | Rainbow

* Description:
This program simulates a set of points moving along an arc whiles changing.
*/

const START_TIME = new Date().getTime();

function setup() {
  createCanvas(windowWidth, windowHeight);

  const NUM_BOWS = 50
  const ORIGIN = createVector(width * 0.5, height * 0.9);
  this.rainbow = new Rainbow(NUM_BOWS, ORIGIN, width, height);
}

let i = 10;
let decreaseI = true;

function draw() {
  background(0, i);

  const ELAPSED_TIME = (new Date().getTime() - START_TIME) / 1000;
  this.rainbow.beginPolyrhythm(ELAPSED_TIME);

  if (i <= -10) {
    decreaseI = false;
  }

  if (i >= 10) {
    decreaseI = true;
  }

  i += decreaseI ? -0.01 : 0.01;
}