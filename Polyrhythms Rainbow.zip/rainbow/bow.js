class Bow {
    constructor(dimention, origin, index) {
        this.dimention = dimention;
        this.index = index;
        this.point = new Point(origin, this.dimention / 2);
    }

    render(origin, elapsedTime) {
        this.point.render(elapsedTime);
    }

    update(origin, elapsedTime) {
        this.point.update(origin, this.dimention / 2, elapsedTime, this.index);
    }
}