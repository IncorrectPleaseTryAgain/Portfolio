class Point {
    constructor(origin, bowRadius) {

        this.pos = createVector(
            bowRadius * cos(PI) + origin.x,
            bowRadius * sin(PI) + origin.y,
        );
    }

    render(elapsedTime) {
        push();
        strokeWeight(abs(15 * cos(elapsedTime * 0.1)) + 5);
        stroke(abs(255 * cos(elapsedTime * 0.05)));
        point(this.pos.x, this.pos.y);
        pop();
    }

    update(origin, bowRadius, elapsedTime, index) {

        const velocity = (TWO_PI * 10 - index) / 60,
            rawAngle = (PI + (elapsedTime * velocity)) % TWO_PI,
            finalAngle = rawAngle >= PI ? rawAngle : TWO_PI - rawAngle;

        this.pos = createVector(
            bowRadius * cos(finalAngle) + origin.x,
            bowRadius * sin(finalAngle) + origin.y,
        );


        console.log(elapsedTime);
    }
}