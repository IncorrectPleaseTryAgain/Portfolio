class Rainbow {
    constructor(numBows, origin, canvasWidth, canvasHeight) {
        this.origin = origin;
        this.bows = [];

        const BOW_GAP = 0.3;
        const AR = canvasWidth / canvasHeight;
        for (let i = 0; i < numBows; i++) {
            const DIM = ((numBows * BOW_GAP) * AR) * (i + 1);
            this.bows[i] = new Bow(DIM, this.origin, i);
        }
    }

    beginPolyrhythm(elapsedTime) {
        this.bows.forEach(bow => {
            bow.render(this.origin, elapsedTime);
            bow.update(this.origin, elapsedTime);
        })
    }
}